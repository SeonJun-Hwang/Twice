package sysproj.seonjoon.twice;

public interface DBAccessResultCallback {

    void AccessCallback(boolean isSuccess);
}
