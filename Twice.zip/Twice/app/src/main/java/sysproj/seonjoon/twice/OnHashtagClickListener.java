package sysproj.seonjoon.twice;

public interface OnHashtagClickListener {

    void onClickHashTag(String hashtag);
}
