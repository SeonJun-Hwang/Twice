package sysproj.seonjoon.twice;

public interface OnLoadMoreListener {

    void onLoadMore();
}
