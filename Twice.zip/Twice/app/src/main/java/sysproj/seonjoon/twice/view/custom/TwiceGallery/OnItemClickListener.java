package sysproj.seonjoon.twice.view.custom.TwiceGallery;

public interface OnItemClickListener {

    void OnItemClick(GalleryAdapter.PhotoViewHolder photoViewHolder , int position);
}