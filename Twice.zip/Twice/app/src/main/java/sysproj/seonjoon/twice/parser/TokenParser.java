package sysproj.seonjoon.twice.parser;

import java.util.Map;

public interface TokenParser {

    Object map2Token(Map<String, Object> data);
}
